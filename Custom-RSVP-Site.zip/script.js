const scriptURL = 'https://script.google.com/macros/s/AKfycbx1oNv6Yg8Fu7ksg302_9eE5dD1B5wzo7EWpo5WS-cs9d1XjISAaT7sLzKSomkW6AM/exec';

document.getElementById('rsvpForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const form = e.target;

  fetch(scriptURL, {
    method: 'POST',
    body: new FormData(form),
  })
    .then(response => {
      document.getElementById('status').innerHTML = '✅ Terima kasih! Kehadiran anda telah direkod.';
      form.reset();
    })
    .catch(error => {
      document.getElementById('status').innerHTML = '❌ Maaf, ada masalah. Sila cuba lagi.';
      console.error('Error!', error.message);
    });
});

LANGKAH SETUP WEBSITE RSVP DI GITHUB PAGES

1. Login ke GitHub dan buat repository baru. Contoh: `rsvp`

2. Upload fail-fail berikut ke repo:
   - index.html
   - style.css
   - script.js

3. Pergi ke Settings > Pages:
   - Source: `main` branch
   - Folder: `/root`
   - Klik Save

4. Dapatkan URL GitHub Pages kamu. Contoh:
   https://namakamu.github.io/rsvp

5. Uji website RSVP kamu. Data akan dihantar ke Google Sheets (pastikan script URL betul dalam script.js).

SIAP! Kamu boleh letakkan link RSVP ini dalam Google Sites.
